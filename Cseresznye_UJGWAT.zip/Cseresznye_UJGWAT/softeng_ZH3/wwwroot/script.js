﻿const baseUrl = "/api/author";
const btnAllAuthors = document.getElementById("btnAllAuthors");
const btnGetAuthor = document.getElementById("btnGetAuthor");
const btnGetGenre = document.getElementById("btnGetGenre");
const btnAddAuthor = document.getElementById("btnAddAuthor");
const btnUpdateAuthor = document.getElementById("btnUpdateAuthor");
const btnDeleteAuthor = document.getElementById("btnDeleteAuthor");
const btnGoogleBooks = document.getElementById("btnGoogleBooks");
const allAuthorsSection = document.getElementById("allAuthorsSection");
const getAuthorSection = document.getElementById("getAuthorSection");
const getGenreSection = document.getElementById("getGenreSection");
const addAuthorSection = document.getElementById("addAuthorSection");
const updateAuthorSection = document.getElementById("updateAuthorSection");
const deleteAuthorSection = document.getElementById("deleteAuthorSection");
const googleBooksSection = document.getElementById("googleBooksSection");
const authorsContainer = document.getElementById("authorsContainer");
const authorIdInput = document.getElementById("authorIdInput");
const authorIdSearchBtn = document.getElementById("authorIdSearchBtn");
const authorResult = document.getElementById("authorResult");
const genreIdInput = document.getElementById("genreIdInput");
const genreIdSearchBtn = document.getElementById("genreIdSearchBtn");
const genreResult = document.getElementById("genreResult");
const newAuthorName = document.getElementById("newAuthorName");
const newAuthorBirthYear = document.getElementById("newAuthorBirthYear");
const newAuthorNationality = document.getElementById("newAuthorNationality");
const addAuthorBtn = document.getElementById("addAuthorBtn");
const addAuthorResult = document.getElementById("addAuthorResult");
const updateAuthorIdInput = document.getElementById("updateAuthorIdInput");
const updateAuthorName = document.getElementById("updateAuthorName");
const updateAuthorBirthYear = document.getElementById("updateAuthorBirthYear");
const updateAuthorNationality = document.getElementById("updateAuthorNationality");
const updateAuthorBtn = document.getElementById("updateAuthorBtn");
const updateAuthorResult = document.getElementById("updateAuthorResult");
const deleteAuthorIdInput = document.getElementById("deleteAuthorIdInput");
const deleteAuthorBtn = document.getElementById("deleteAuthorBtn");
const deleteAuthorResult = document.getElementById("deleteAuthorResult");
const googleBooksQuery = document.getElementById("googleBooksQuery");
const googleBooksSearchBtn = document.getElementById("googleBooksSearchBtn");
const googleBooksResult = document.getElementById("googleBooksResult");
const weatherContainer = document.getElementById("weatherContainer");

btnAllAuthors.addEventListener("click", () => showSection(allAuthorsSection));
btnGetAuthor.addEventListener("click", () => showSection(getAuthorSection));
btnGetGenre.addEventListener("click", () => showSection(getGenreSection));
btnAddAuthor.addEventListener("click", () => showSection(addAuthorSection));
btnUpdateAuthor.addEventListener("click", () => showSection(updateAuthorSection));
btnDeleteAuthor.addEventListener("click", () => showSection(deleteAuthorSection));
btnGoogleBooks.addEventListener("click", () => showSection(googleBooksSection));
googleBooksSearchBtn.addEventListener("click", searchGoogleBooks);

function showSection(section) {
    allAuthorsSection.classList.add("hidden");
    getAuthorSection.classList.add("hidden");
    getGenreSection.classList.add("hidden");
    addAuthorSection.classList.add("hidden");
    updateAuthorSection.classList.add("hidden");
    deleteAuthorSection.classList.add("hidden");
    googleBooksSection.classList.add("hidden");
    section.classList.remove("hidden");
    if (section === allAuthorsSection) {
        loadAllAuthors();
    }
}

function loadAllAuthors() {
    authorsContainer.innerHTML = "Betöltés...";
    fetch(baseUrl)
        .then(res => {
            if (!res.ok) {
                throw new Error("Hiba a szerzők lekérésekor");
            }
            return res.json();
        })
        .then(data => {
            renderAuthorsTable(data);
        })
        .catch(err => {
            authorsContainer.innerHTML = `<p style="color:red;">${err.message}</p>`;
        });
}

function renderAuthorsTable(authors) {
    if (!authors || authors.length === 0) {
        authorsContainer.innerHTML = "<p>Nincs elérhető szerző.</p>";
        return;
    }
    let html = "<table><thead><tr><th>ID</th><th>Név</th><th>Születési év</th><th>Nemzetiség</th></tr></thead><tbody>";
    authors.forEach(a => {
        html += `<tr><td>${a.authorId}</td><td>${a.name}</td><td>${a.birthYear || ''}</td><td>${a.nationality || ''}</td></tr>`;
    });
    html += "</tbody></table>";
    authorsContainer.innerHTML = html;
}

authorIdSearchBtn.addEventListener("click", () => {
    const id = authorIdInput.value.trim();
    if (!id) {
        authorResult.innerHTML = `<p style="color:red;">Adjon meg egy érvényes ID-t!</p>`;
        return;
    }
    authorResult.innerHTML = "Betöltés...";
    fetch(`${baseUrl}/${id}`)
        .then(res => {
            if (!res.ok) {
                if (res.status === 404) {
                    throw new Error("Nincs ilyen ID-jű szerző!");
                }
                throw new Error("Hiba a lekérés során");
            }
            return res.json();
        })
        .then(author => {
            authorResult.innerHTML = `<p>ID: ${author.authorId}</p><p>Név: ${author.name}</p><p>Születési év: ${author.birthYear || ''}</p><p>Nemzetiség: ${author.nationality || ''}</p>`;
        })
        .catch(err => {
            authorResult.innerHTML = `<p style="color:red;">${err.message}</p>`;
        });
});

genreIdSearchBtn.addEventListener("click", () => {
    const id = genreIdInput.value.trim();
    if (!id) {
        genreResult.innerHTML = `<p style="color:red;">Adjon meg egy érvényes Műfaj ID-t!</p>`;
        return;
    }
    genreResult.innerHTML = "Betöltés...";
    fetch(`${baseUrl}/genre/${id}`)
        .then(res => {
            if (!res.ok) {
                if (res.status === 404) {
                    throw new Error("Nincs ilyen ID-jű műfaj!");
                }
                throw new Error("Hiba a lekérés során");
            }
            return res.json();
        })
        .then(genre => {
            genreResult.innerHTML = `<p>ID: ${genre.genreId}</p><p>Műfaj: ${genre.genreName}</p>`;
        })
        .catch(err => {
            genreResult.innerHTML = `<p style="color:red;">${err.message}</p>`;
        });
});

addAuthorBtn.addEventListener("click", () => {
    const name = newAuthorName.value.trim();
    const birthYear = newAuthorBirthYear.value.trim();
    const nationality = newAuthorNationality.value.trim();
    if (!name) {
        addAuthorResult.innerHTML = `<p style="color:red;">A név megadása kötelező!</p>`;
        return;
    }
    const newAuthor = {
        authorId: 0,
        name: name,
        birthYear: birthYear ? parseInt(birthYear) : 0,
        nationality: nationality || "string"
    };
    fetch(baseUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newAuthor)
    })
        .then(res => {
            if (!res.ok) {
                throw new Error("Hiba a szerző hozzáadásakor");
            }
            return res.text();
        })
        .then(() => {
            addAuthorResult.innerHTML = `<p style="color:green;">Szerző sikeresen hozzáadva!</p>`;
            newAuthorName.value = "";
            newAuthorBirthYear.value = "";
            newAuthorNationality.value = "";
        })
        .catch(err => {
            addAuthorResult.innerHTML = `<p style="color:red;">${err.message}</p>`;
        });
});

updateAuthorBtn.addEventListener("click", () => {
    const id = updateAuthorIdInput.value.trim();
    if (!id) {
        updateAuthorResult.innerHTML = `<p style="color:red;">Adjon meg egy érvényes Szerző ID-t!</p>`;
        return;
    }
    const name = updateAuthorName.value.trim();
    const birthYear = updateAuthorBirthYear.value.trim();
    const nationality = updateAuthorNationality.value.trim();
    const updatedAuthor = {
        authorId: parseInt(id),
        name: name || "string",
        birthYear: birthYear ? parseInt(birthYear) : 0,
        nationality: nationality || "string"
    };
    fetch(`${baseUrl}/${id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedAuthor)
    })
        .then(res => {
            if (!res.ok) {
                throw new Error("Hiba a szerző módosításakor");
            }
            return res.text();
        })
        .then(msg => {
            updateAuthorResult.innerHTML = `<p style="color:green;">${msg}</p>`;
        })
        .catch(err => {
            updateAuthorResult.innerHTML = `<p style="color:red;">${err.message}</p>`;
        });
});

deleteAuthorBtn.addEventListener("click", () => {
    const id = deleteAuthorIdInput.value.trim();
    if (!id) {
        deleteAuthorResult.innerHTML = `<p style="color:red;">Adjon meg egy érvényes Szerző ID-t!</p>`;
        return;
    }
    fetch(`${baseUrl}/${id}`, {
        method: "DELETE"
    })
        .then(res => {
            if (!res.ok) {
                throw new Error("Hiba a törlés során!");
            }
            return res.text();
        })
        .then(msg => {
            deleteAuthorResult.innerHTML = `<p style="color:green;">${msg}</p>`;
        })
        .catch(err => {
            deleteAuthorResult.innerHTML = `<p style="color:red;">${err.message}</p>`;
        });
});

function searchGoogleBooks() {
    const query = googleBooksQuery.value.trim();
    if (!query) {
        googleBooksResult.innerHTML = `<p style="color:red;">Adjon meg egy keresőkifejezést!</p>`;
        return;
    }
    googleBooksResult.innerHTML = "Betöltés...";
    fetch(`https://www.googleapis.com/books/v1/volumes?q=${encodeURIComponent(query)}`)
        .then(res => {
            if (!res.ok) {
                throw new Error("Hiba a Google Books lekérés során");
            }
            return res.json();
        })
        .then(data => {
            if (!data.items || data.items.length === 0) {
                googleBooksResult.innerHTML = "<p>Nincs találat.</p>";
                return;
            }
            renderGoogleBooks(data.items);
        })
        .catch(err => {
            googleBooksResult.innerHTML = `<p style="color:red;">${err.message}</p>`;
        });
}

function renderGoogleBooks(books) {
    let html = "<ul>";
    books.forEach(book => {
        const title = book.volumeInfo.title || "Nincs cím";
        const authors = book.volumeInfo.authors ? book.volumeInfo.authors.join(", ") : "Ismeretlen szerző(k)";
        const cover = book.volumeInfo.imageLinks && book.volumeInfo.imageLinks.thumbnail ? book.volumeInfo.imageLinks.thumbnail : "";
        html += `<li>${cover ? `<img src="${cover}" alt="cover" class="book-cover"/>` : ''}<div><strong>${title}</strong><br/>Szerző(k): ${authors}</div></li>`;
    });
    html += "</ul>";
    googleBooksResult.innerHTML = html;
}

function loadWeather() {
    fetch("https://api.open-meteo.com/v1/forecast?latitude=47.4979&longitude=19.0402&current_weather=true")
        .then(res => {
            if (!res.ok) {
                throw new Error("Hiba az időjárás lekérésekor");
            }
            return res.json();
        })
        .then(data => {
            const temp = data.current_weather.temperature;
            const code = data.current_weather.weathercode;
            const description = interpretWeatherCode(code);
            weatherContainer.innerHTML = `Budapest: ${temp}°C, ${description}`;
        })
        .catch(err => {
            weatherContainer.innerHTML = `<p style="color:red;">Időjárás hiba: ${err.message}</p>`;
        });
}

function interpretWeatherCode(code) {
    switch (code) {
        case 0: return "Derült";
        case 1:
        case 2:
        case 3: return "Részben felhős";
        case 45:
        case 48: return "Köd";
        case 51:
        case 53:
        case 55: return "Enyhe eső";
        case 61:
        case 63:
        case 65: return "Eső";
        case 80:
        case 81:
        case 82: return "Záporok";
        case 95:
        case 96:
        case 99: return "Zivatar";
        default: return "Ismeretlen időjárás";
    }
}

document.addEventListener("DOMContentLoaded", loadWeather);
