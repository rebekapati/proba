﻿using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using softeng_ZH3.Models;
using System.Security.Cryptography.X509Certificates;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace softeng_ZH3.Controllers
{
    [Route("api/author")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        // GET: api/author>
        [HttpGet]
        public IActionResult Get()
        {
            SoftengLibraryContext context = new SoftengLibraryContext();
            return Ok(context.Authors.ToList());


            /*
            var books = (from b in context.Books
                         join a in context.Authors on b.AuthorId equals a.AuthorId
                         join br in context.Borrowers on b.BookId equals br.BookId
                         select new
                         {
                             BookId = b.BookId,
                             Title = b.Title,
                             AuthorID = b.AuthorId,
                             GenreID = b.GenreId,
                             PublicationYear = b.PublicationYear,
                             ISBN = b.Isbn,
                             AuthorName = a.Name,
                             BorrowerName = br.Name
                         }).ToList();
            return Ok(books);*/
        }

        // GET api/author/genre/5
        [HttpGet("genre/{id}")]
        public IActionResult GetGenre(int id)
        {
            SoftengLibraryContext context = new SoftengLibraryContext();
            var genre = (from g in context.Genres
                        where g.GenreId == id
                        select g).FirstOrDefault();

            if (genre == null)
            {
                return NotFound();
            }

            return Ok(genre);


            /*
            var book = (from b in context.Books
                         join a in context.Authors on b.AuthorId equals a.AuthorId
                         join br in context.Borrowers on b.BookId equals br.BookId
                        where b.BookId == id
                        select new
                         {
                             BookId = b.BookId,
                             Title = b.Title,
                             AuthorID = b.AuthorId,
                             AuthorName = a.Name,
                             GenreID = b.GenreId,
                             Genre = b.Genre,
                             BorrowerName = br.Name,
                             PublicationYear = b.PublicationYear,
                             ISBN = b.Isbn
                         }).FirstOrDefault();

            return Ok(book);
            if (book == null)
            {
                return NotFound();
            }

            return Ok(book);*/
        }

        
        // GET api/author/5
        [HttpGet("{id}")]
        public IActionResult GetAuthor(int id)
        {
            SoftengLibraryContext context = new SoftengLibraryContext();
            var author = (from a in context.Authors
                        where a.AuthorId == id
                        select a).FirstOrDefault();

            if (author == null)
            {
                return NotFound();
            }

            return Ok(author);
        }

        // POST api/author
        [HttpPost]
        public void Post([FromBody] Author author)
        {
            SoftengLibraryContext context = new SoftengLibraryContext();
            context.Authors.Add(author);
            context.SaveChanges();
        }

        // PUT api/author/5
        [HttpPut("{id}")]
        public IActionResult PutAuthor(int id, [FromBody] Author value)
        {
            SoftengLibraryContext context = new SoftengLibraryContext();
            var authormod = (from a in context.Authors
                             where a.AuthorId == id
                             select a).FirstOrDefault();

            if (authormod == null)
            {
                return NotFound();
            }

            authormod.Name = value.Name;
            authormod.BirthYear = value.BirthYear;
            authormod.Nationality = value.Nationality;

            context.SaveChanges();

            return Ok("Sikeres módosítás");
        }

        // POST api/genre/update
        [HttpPost("genre/update")]
        public IActionResult PutGenre(int id, [FromBody] Genre value)
        {
            SoftengLibraryContext context = new SoftengLibraryContext();
            var genremod = (from g in context.Genres
                             where g.GenreId == value.GenreId
                             select g).FirstOrDefault();

            if (genremod == null)
            {
                return NotFound();
            }

            genremod.GenreName = value.GenreName;

            context.SaveChanges();

            return Ok("Sikeres módosítás");
        }

        // POST api/author/update
        [HttpPost("update/new")]
        public IActionResult PostAuthor(int id, [FromBody] Author value)
        {
            SoftengLibraryContext context = new SoftengLibraryContext();
            var authormod = (from a in context.Authors
                             where a.AuthorId == value.AuthorId
                             select a).FirstOrDefault();

            if (authormod == null)
            {
                return NotFound();
            }

            authormod.Name = value.Name;
            authormod.BirthYear = value.BirthYear;
            authormod.Nationality = value.Nationality;

            context.SaveChanges();

            return Ok("Sikeres módosítás");
        }

        // DELETE api/author/5
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            SoftengLibraryContext context = new SoftengLibraryContext();
            var authordel = (from a in context.Authors
                             where a.AuthorId == id
                             select a).FirstOrDefault();

            if (authordel == null)
            {
                return NotFound();
            }
            context.Authors.Remove(authordel);
            context.SaveChanges();

            return Ok("sikeres törlés!");
        }
    }
}
