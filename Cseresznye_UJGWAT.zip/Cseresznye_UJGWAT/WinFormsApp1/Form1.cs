﻿using Microsoft.EntityFrameworkCore.Metadata.Conventions;
using WinFormsApp1.Models;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        SoftengLibraryContext context = new SoftengLibraryContext();

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            UserControl1 userControl = new UserControl1();
            panel1.Controls.Clear();
            userControl.Dock = DockStyle.Fill;
            panel1.Controls.Add(userControl);

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2();

            if (form2.ShowDialog() == DialogResult.OK)
            {

                // Adatok validálása
                if (string.IsNullOrEmpty(form2.ujSzerzo.Name) || string.IsNullOrEmpty(form2.ujSzerzo.Nationality))
                {
                    MessageBox.Show("Az összes mező kitöltése kötelező!", "Hiba", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                    context.Authors.Add(form2.ujSzerzo);
                    context.SaveChanges();

                MessageBox.Show("Új szerző sikeresen hozzáadva!", "Siker", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("A rekord hozzáadása megszakadt.", "Figyelem", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

    }
}
