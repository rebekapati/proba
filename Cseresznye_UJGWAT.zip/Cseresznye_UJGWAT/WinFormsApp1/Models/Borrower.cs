﻿using System;
using System.Collections.Generic;

namespace WinFormsApp1.Models;

public partial class Borrower
{
    public int BorrowerId { get; set; }

    public string Name { get; set; } = null!;

    public string? Email { get; set; }

    public DateTime? BorrowDate { get; set; }

    public int? BookId { get; set; }

    public DateTime? BroughtBackDate { get; set; }

    public virtual Book? Book { get; set; }
}
